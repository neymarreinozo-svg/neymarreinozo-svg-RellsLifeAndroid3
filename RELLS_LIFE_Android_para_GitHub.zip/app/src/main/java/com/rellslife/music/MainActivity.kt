package com.rellslife.music

import android.Manifest
import android.app.Activity
import android.content.ContentUris
import android.content.pm.PackageManager
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private data class Track(val id: Long, val title: String, val artist: String, val uri: Uri)
    private val tracks = mutableListOf<Track>()
    private var player: MediaPlayer? = null
    private lateinit var list: LinearLayout
    private lateinit var status: TextView
    private lateinit var nowPlaying: TextView
    private lateinit var playPause: Button
    private val favorites by lazy { getSharedPreferences("rell_favorites", MODE_PRIVATE) }
    private val audioPermission get() = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(10, 10, 12)
        window.navigationBarColor = Color.rgb(10, 10, 12)
        buildScreen()
        if (hasAudioPermission()) loadTracks() else requestPermissions(arrayOf(audioPermission), 41)
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 28, 22, 18)
            setBackgroundColor(Color.rgb(10, 10, 12))
        }
        root.addView(TextView(this).apply {
            text = "RELL'S LIFE"; textSize = 27f; setTextColor(Color.WHITE); letterSpacing = 0.18f
        })
        root.addView(TextView(this).apply {
            text = "YOUR MUSIC. YOUR WORLD."; textSize = 10f; letterSpacing = 0.22f
            setTextColor(Color.LTGRAY); setPadding(0, 5, 0, 18)
        })
        status = TextView(this).apply {
            text = "Buscando tu música..."; textSize = 14f; setTextColor(Color.LTGRAY); setPadding(0, 8, 0, 12)
        }
        root.addView(status)
        nowPlaying = TextView(this).apply {
            text = "Nada reproduciéndose"; textSize = 16f; setTextColor(Color.WHITE); setPadding(0, 12, 0, 8)
        }
        root.addView(nowPlaying)
        playPause = Button(this).apply {
            text = "PAUSAR"
            setOnClickListener {
                player?.let { p ->
                    if (p.isPlaying) { p.pause(); text = "REANUDAR" }
                    else { p.start(); text = "PAUSAR" }
                }
            }
        }
        root.addView(playPause)
        root.addView(TextView(this).apply {
            text = "TU BIBLIOTECA"; textSize = 12f; letterSpacing = 0.16f
            setTextColor(Color.rgb(185, 185, 195)); setPadding(0, 20, 0, 10)
        })
        val scroll = ScrollView(this)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun hasAudioPermission() = Build.VERSION.SDK_INT < 23 || checkSelfPermission(audioPermission) == PackageManager.PERMISSION_GRANTED

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 41 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) loadTracks()
        else status.text = "Permite el acceso a audio para mostrar tus canciones."
    }

    private fun loadTracks() {
        tracks.clear()
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST)
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
        contentResolver.query(collection, projection, selection, null, "${MediaStore.Audio.Media.TITLE} ASC")?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                val title = cursor.getString(titleCol) ?: "Canción sin título"
                val rawArtist = cursor.getString(artistCol)
                val artist = if (rawArtist.isNullOrBlank() || rawArtist == "<unknown>") "Artista desconocido" else rawArtist
                tracks.add(Track(id, title, artist, ContentUris.withAppendedId(collection, id)))
            }
        }
        status.text = if (tracks.isEmpty()) "No encontramos canciones. Añade MP3 a tu celular." else "${tracks.size} canciones encontradas"
        renderTracks()
    }

    private fun renderTracks() {
        list.removeAllViews()
        tracks.forEach { track ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, 10, 0, 10) }
            val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            info.addView(TextView(this).apply { text = track.title; textSize = 15f; setTextColor(Color.WHITE); maxLines = 1 })
            info.addView(TextView(this).apply { text = track.artist; textSize = 12f; setTextColor(Color.LTGRAY); maxLines = 1 })
            row.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(Button(this).apply {
                text = if (isFavorite(track)) "♥" else "♡"
                setOnClickListener { setFavorite(track, !isFavorite(track)); text = if (isFavorite(track)) "♥" else "♡" }
            })
            row.setOnClickListener { play(track) }
            list.addView(row)
            list.addView(View(this).apply { setBackgroundColor(Color.rgb(45, 45, 50)) }, LinearLayout.LayoutParams(-1, 1))
        }
    }

    private fun isFavorite(track: Track) = favorites.getBoolean(track.id.toString(), false)
    private fun setFavorite(track: Track, value: Boolean) { favorites.edit().putBoolean(track.id.toString(), value).apply() }

    private fun play(track: Track) {
        try {
            player?.release()
            player = MediaPlayer.create(this, track.uri)
            if (player == null) { nowPlaying.text = "No se pudo abrir: ${track.title}"; return }
            player?.setOnCompletionListener { playPause.text = "REPRODUCIR" }
            player?.start()
            nowPlaying.text = "▶  ${track.title} — ${track.artist}"
            playPause.text = "PAUSAR"
        } catch (_: Exception) { nowPlaying.text = "Error al reproducir esta canción" }
    }

    override fun onDestroy() { player?.release(); player = null; super.onDestroy() }
}
