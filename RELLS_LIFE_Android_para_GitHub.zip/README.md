# RELL'S LIFE

Reproductor Android de música local. Esta versión inicial busca canciones de audio disponibles en el dispositivo, permite reproducirlas y guardar favoritos.

## Compilar
GitHub Actions compila un APK de depuración al hacer push a `main` o al ejecutarlo manualmente desde Actions. El archivo generado se publica como artefacto `RellsLife-debug-apk`.

## Estado
Versión inicial de prueba. Aún requiere pruebas en un dispositivo Android real.
